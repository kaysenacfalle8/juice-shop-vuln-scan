# Vulnerability Scanning Report: OWASP Juice Shop (Nikto Scan)

**Project Title:** Vulnerability Assessment of OWASP Juice Shop using Nikto  
**Date:** [Insert Date]  
**Platform:** Kali Linux  
**Tool Used:** Nikto v2.5.0  
**Target URL:** http://127.0.0.1:3000

## 1. Objective
The goal of this beginner-level project is to run a basic vulnerability scan on OWASP Juice Shop (a purposely insecure web app) using Nikto. This helps identify files or settings that shouldn't be exposed to the public. The findings are documented in a semi-formal format to demonstrate understanding of vulnerability scanning in practice.

## 2. Environment Setup
- Operating System: Kali Linux
- Application Target: OWASP Juice Shop (local instance)
- Scanning Tool: Nikto
- Commands Used: `nikto -h http://127.0.0.1:3000`

## 3. Key Finding: Publicly Accessible Backup and Certificate Files
**CWE:** CWE-530 – Backup File Exposure  
**Risk Level:** High  

### Description:
Nikto found several files that look like backups, certificates, or app code bundles. These were available directly through the browser without needing to log in. The file types included .pem, .war, .tar, .tgz, .bz2, .cer, .jks, and .egg.

### Evidence from Nikto Output:
- /dump.egg: Potentially interesting backup/cert file found.
- /127.0.0.1.jks: Potentially interesting backup/cert file found.
- /database.cer: Potentially interesting backup/cert file found.
- /backup.tgz: Potentially interesting backup/cert file found.
- /database.war: Potentially interesting backup/cert file found.

### Impact:
These files may contain:
- Source code or compiled app logic
- SSL certificates or private keys
- Environment configs or secrets
- User data or database backups

An attacker could:
- Understand how the app works
- Steal credentials or keys
- Imitate the server using stolen certificates
- Restore old data from the backup

### Remediation:
- Delete any backup or sensitive files from the web folder
- Use server rules (like .htaccess) to block access to file types like .cer, .jks, etc.
- Set up a process to check for exposed files before launching your app

## 4. Recommendations
- Add Nikto or similar tools into your dev process to catch risks early
- Set up strict file access rules at the server level
- Regularly clean your web folder and remove unused files
- Use .gitignore to avoid uploading sensitive stuff to GitHub or public repos

## 5. Conclusion
This scan revealed a serious but common vulnerability: exposed backup and cert files. While Juice Shop is designed to be insecure, scanning it shows how easy it can be to overlook these issues in real apps. Learning how to spot and fix them is a key step in improving cybersecurity awareness and skills.
