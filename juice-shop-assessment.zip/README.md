# OWASP Juice Shop Vulnerability Assessment

This project demonstrates a beginner-friendly web app pentest using Kali Linux tools against the OWASP Juice Shop vulnerable application.

## 🔧 Tools Used
- **Kali Linux**
- **Nikto** – for web vulnerability scanning
- **Nmap** – for port and service enumeration
- **OWASP Juice Shop** – intentionally insecure app for ethical hacking practice

## ✅ Challenges Solved
- Error Handling (Improper error message exposure)

## 🖼️ Screenshots
See `/screenshots` for:
- Nikto scan results
- Nmap enumeration
- Challenge completion banner

## 📄 Findings Summary
- Discovered potentially sensitive backup/cert files (CWE-530)
- Detected improper error handling (CWE-388)
- Found uncommon headers and missing security headers (X-Content-Type-Options)

## 📚 CWE References
- https://cwe.mitre.org/data/definitions/530.html
- https://cwe.mitre.org/data/definitions/388.html
